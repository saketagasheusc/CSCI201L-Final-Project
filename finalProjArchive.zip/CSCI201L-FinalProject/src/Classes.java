import java.util.ArrayList;

public class Classes {
	private int classID; //TODO: Get classID from SQL database
	private String courseCode;
	private String departmentCode;
	private String courseName;
	private ArrayList<Professor> Professors;
	private ArrayList<Review> Reviews;
	private Boolean isVerified;
	private int avgRatingDifficulty;
	private int avgRatingInteresting;
	
	//TODO: integrate SQL with the class
	public Classes(String courseCode, String departmentCode, String courseName, 
			ArrayList<Professor> Professors) {
		this.courseCode =  courseCode;
		this.departmentCode = departmentCode;
		this.courseName = courseName;
		this.Professors = Professors;
		Reviews = new ArrayList<Review>();
		isVerified = false;
	}

	public int getClassID() {
		return classID;
	}
	public void setClassID(int classID) {
		this.classID = classID;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public String getDepartmentCode() {
		return departmentCode;
	}
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public ArrayList<Professor> getProfessors() {
		return Professors;
	}
	public void setProfessors(ArrayList<Professor> professors) {
		Professors = professors;
	}
	public ArrayList<Review> getReviews() {
		return Reviews;
	}
	public void setReviews(ArrayList<Review> reviews) {
		Reviews = reviews;
	}
	public Boolean getIsVerified() {
		return isVerified;
	}
	public void setIsVerified(Boolean isVerified) {
		this.isVerified = isVerified;
	}
	public int getAvgRatingDifficulty() {
		return avgRatingDifficulty;
	}
	public void setAvgRatingDifficulty(int avgRatingDifficulty) {
		this.avgRatingDifficulty = avgRatingDifficulty;
	}
	//TODO: CALCULATE BASED ON REVIEWS
	public int getAvgRatingInteresting() {
		return avgRatingInteresting;
	}
	public void setAvgRatingInteresting(int avgRatingInteresting) {
		this.avgRatingInteresting = avgRatingInteresting;
	}
}
