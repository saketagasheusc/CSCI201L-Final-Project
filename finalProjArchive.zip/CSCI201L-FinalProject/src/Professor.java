import java.util.ArrayList;

public class Professor {
	private int profID;
	ArrayList<Classes> classes;
	ArrayList<Review> Reviews;
	String name;
	
	
	
}
