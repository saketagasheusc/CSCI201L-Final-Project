import java.util.ArrayList;

public class User {
	private int userID; // TODO: get userID from SQL database
	private ArrayList<Classes> registeredClasses;
	private ArrayList<Integer> userReviews;
	private String firstName;
	private String lastName;
	private int gradYear;
	private String major;
	private String uName;
	private String passWord;
	private String email;
	
	//TODO: Integrate SQL With the Class
	public User(String firstName,
	String lastName, int gradYear, String major, String uName, String passWord, String email) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gradYear = gradYear;
		this.major = major;
		this.uName = uName;
		this.passWord = passWord;
		this.email = email;
		userReviews = new ArrayList<Integer>();
	}
	
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public ArrayList<Classes> getRegisteredClasses() {
		return registeredClasses;
	}
	public void setRegisteredClasses(ArrayList<Classes> registeredClasses) {
		this.registeredClasses = registeredClasses;
	}
	public ArrayList<Integer> getUserReviews() {
		return userReviews;
	}
	public void setUserReviews(ArrayList<Integer> userReviews) {
		this.userReviews = userReviews;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getGradYear() {
		return gradYear;
	}
	public void setGradYear(int gradYear) {
		this.gradYear = gradYear;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void addReview(Review review) {
		//TODO
	}
	public void removeReview(Review review) {
		//TODO
	}
}
